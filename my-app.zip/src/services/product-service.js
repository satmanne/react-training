import axios from "axios";

export function getProducts() {
  const url =
    "https://raw.githubusercontent.com/mdmoin7/Random-Products-Json-Generator/master/products.json";
  return axios.get(url);
}
