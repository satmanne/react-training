import axios from "axios";

export function getMenuItems() {
  const url = "/menu.json";
  return axios.get(url);
}
