import React from "react";
import "./App.css";
import Currency from "./components/Currency";
import ThemeSwitch from "./components/ThemeSwitch";
import AppRouter from "./Routes";
import Header from "./containers/Header";
import Container from "./components/Container";
import { BrowserRouter } from "react-router-dom";
import CartIcon from "./components/CartIcon";
import LoginButtons from "./components/LoginButtons";

export const ThemeContext = React.createContext();

class App extends React.Component {
  state = {
    currentCurrency: "INR",
    theme: false,
    cartData: []
  };
  componentDidUpdate() {
    const themeClass = this.state.theme ? "bg-dark" : "";
    document.body.className = themeClass;
  }
  render() {
    return (
      <BrowserRouter>
        <Header theme={this.state.theme}>
          <CartIcon />
          <ThemeSwitch changeTheme={theme => this.setState({ theme })} />
          <Currency
            changeCurrency={c => {
              console.log("app", c);
              this.setState({ currentCurrency: c });
            }}
          />
          <LoginButtons theme={this.state.theme} />
        </Header>
        <Container full>
          <ThemeContext.Provider value={this.state.theme}>
            <AppRouter />
          </ThemeContext.Provider>
        </Container>
        {/* <ProductList
            currencyCode={currentCurrency}
            addItem={product => {
              this.setState({
                cartData: [
                  ...this.state.cartData,
                  { ...product, productQty: 1 }
                ]
              });
            }}
          />
          <Cart
            cartItems={this.state.cartData}
            currencyCode={currentCurrency}
          /> */}
      </BrowserRouter>
    );
  }
}

export default App;
