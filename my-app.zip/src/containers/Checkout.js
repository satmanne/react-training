import React from "react";
import Textbox from "../components/Textbox";
import Column from "../components/Column";
import qs from "querystringify";

class Checkout extends React.Component {
  state = { name: "" };
  emailRef = null;

  saveData = e => {
    e.preventDefault();
    // send data to server
    console.log("submit", this.state, this.emailRef.value);
  };

  render() {
    // /checkout/123
    // console.log("REST PARAMS", this.props.match.params);
    // /checkout/123?name=test&key=test
    // console.log("QUERY PARAMS", qs.parse(this.props.location.search));

    return (
      <Column size={4}>
        <form onSubmit={this.saveData}>
          {/* <label>Name</label>
        <input
          type="text"
          value={this.state.name}
          onChange={e => this.setState({ name: e.currentTarget.value })}
        /> */}
          <Textbox
            type="text"
            name="Name"
            value={this.state.name}
            valueChange={e => this.setState({ name: e })}
          />

          <label>Email</label>
          <input type="text" ref={r => (this.emailRef = r)} />

          <button>Submit</button>
        </form>
      </Column>
    );
  }
}
export default Checkout;
