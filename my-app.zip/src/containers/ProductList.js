import React from "react";
import Product from "../components/Product";
import { getProducts } from "../services/product-service";
import Paginate from "../components/Paginate";
import { chunk } from "lodash";
import Row from "../components/Row";
import { connect } from "react-redux";
import { addToCart } from "../_store/actions";

class ProductList extends React.Component {
  state = { pList: [], page: 1, pagedData: [], pageSize: 10 };

  async componentDidMount() {
    try {
      const res = await getProducts();
      const pagedData = chunk(res.data, this.state.pageSize);
      this.setState({ pList: res.data, pagedData });
    } catch (err) {
      console.log("error", err);
    }
  }
  renderProducts() {
    const { pagedData, page } = this.state;
    return (
      <Row>
        {pagedData.length > 0 &&
          pagedData[page - 1].map(prod => (
            <Product
              pData={prod}
              code={this.props.currencyCode}
              key={prod.productId}
              btnClick={() => {
                // add to cart
                this.props.addItem(prod);
                // navigate to cart
                this.props.history.push("/cart");
              }}
            />
          ))}
        {/* <Product pData={pList} wishlist /> */}
      </Row>
    );
  }
  renderPager() {
    const { pageSize, pList } = this.state;
    return (
      <Paginate
        size={pageSize}
        length={pList.length}
        pageChange={page => this.setState({ page })}
      />
    );
  }
  render() {
    return (
      <>
        {this.renderProducts()}
        {this.renderPager()}
      </>
    );
  }
}
// connect(how to connect)(what to connect/ component)
const mapStateToProps = state => {
  return {
    currencyCode: state.currency
  };
};
const mapDispatchToProps = dispatch => {
  return {
    addItem: p => dispatch(addToCart(p))
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(ProductList);
