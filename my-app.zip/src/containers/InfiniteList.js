import React from "react";
import Product from "../components/Product";
import { getProducts } from "../services/product-service";
import { chunk, debounce } from "lodash";
import Row from "../components/Row";
import { connect } from "react-redux";
import { addToCart } from "../_store/actions";

class ProductList extends React.Component {
  constructor(props) {
    super(props);
    this.state = { pList: [], page: 1, pagedData: [], pageSize: 10 };

    // Binds our scroll event handler
    window.onscroll = debounce(() => {
      // Checks that the page has scrolled to the bottom
      if (
        window.innerHeight + document.documentElement.scrollTop >=
        document.documentElement.offsetHeight - 50
      ) {
        const totalPages = Math.ceil(
          this.state.pList.length / this.state.pageSize
        );
        if (this.state.page < totalPages) {
          let pagedData = chunk(this.state.pList, this.state.pageSize)[
            this.state.page
          ];
          pagedData = [...this.state.pagedData, ...pagedData];
          console.log(pagedData);
          this.setState({ page: this.state.page + 1, pagedData });
        }
      }
    }, 300);
  }

  async componentDidMount() {
    try {
      const res = await getProducts();
      const pagedData = chunk(res.data, this.state.pageSize)[0];
      this.setState({ pList: res.data, pagedData });
    } catch (err) {
      console.log("error", err);
    }
  }
  renderProducts() {
    const { pagedData } = this.state;
    return (
      <Row>
        {pagedData.length > 0 &&
          pagedData.map(prod => (
            <Product
              pData={prod}
              code={this.props.currencyCode}
              key={prod.productId}
              btnClick={() => {
                // add to cart
                this.props.addItem(prod);
                // navigate to cart
                this.props.history.push("/cart");
              }}
            />
          ))}
        {/* <Product pData={pList} wishlist /> */}
      </Row>
    );
  }
  render() {
    return <>{this.renderProducts()}</>;
  }
}
// connect(how to connect)(what to connect/ component)
const mapStateToProps = state => {
  return {
    currencyCode: state.currency
  };
};
const mapDispatchToProps = dispatch => {
  return {
    addItem: p => dispatch(addToCart(p))
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(ProductList);
