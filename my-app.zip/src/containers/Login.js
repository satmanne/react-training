import React from "react";
import Textbox from "../components/Textbox";
import { signIn } from "../_store/actions";
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";
import Row from "../components/Row";
import ButtonWithLoader from "../components/ButtonWithLoader";

class Login extends React.Component {
  state = { email: "", password: "" };

  doLogin = e => {
    const { email, password } = this.state;
    e.preventDefault();
    this.props.login(email, password);
  };

  render() {
    const { email, password } = this.state;

    if (this.props.isLoggedIn) {
      console.log(this.props.location.state);
      const lastPage =
        this.props.location.state && this.props.location.state.from
          ? this.props.location.state.from.pathname
          : "/";

      return <Redirect to={lastPage} />;
    }

    return (
      <Row>
        <form
          onSubmit={this.doLogin}
          className="col-md-4 offset-md-4 alert-info   p-4 shadow"
        >
          {this.props.loginError ? (
            <p className="text-danger">{this.props.loginError.error.message}</p>
          ) : null}
          <Textbox
            type="email"
            name="Email"
            value={email}
            valueChange={email => this.setState({ email })}
          />
          <Textbox
            type="password"
            name="Password"
            value={password}
            valueChange={password => this.setState({ password })}
          />
          <ButtonWithLoader type="submit" block text="Login" color="success" />
        </form>
      </Row>
    );
  }
}
const mapStateToProps = state => {
  return {
    isLoggedIn: !!state.user.user, // obj : true, null : false
    loginError: state.user.error
  };
};
const mapDispatchToProps = dispatch => {
  return {
    login: (e, p) => dispatch(signIn(e, p))
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Login);
