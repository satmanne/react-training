import React from "react";
import { getMenuItems } from "../services/menu-service";
import Menu from "../components/Menu";
import { Link } from "react-router-dom";

class Header extends React.Component {
  state = { menuData: [] };

  async componentDidMount() {
    try {
      const res = await getMenuItems();
      this.setState({ menuData: res.data });
    } catch (e) {
      console.log("error", e);
    }
  }

  render() {
    const { theme } = this.props;
    const cls = theme
      ? "navbar navbar-dark bg-dark navbar-expand-lg"
      : "navbar navbar-light bg-light navbar-expand-lg ";
    return (
      <nav className={cls + " fixed-top shadow-sm"}>
        <Link className="navbar-brand" to="/">
          <i className="fab fa-react"></i>
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <Menu menuItems={this.state.menuData} />
          {this.props.children}
        </div>
      </nav>
    );
  }
}
export default Header;
