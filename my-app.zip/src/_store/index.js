import { createStore, applyMiddleware } from "redux";
import rootReducer from "./reducers";
import thunk from "redux-thunk";
import logger from "redux-logger";
import { loadState, saveState } from "../storage-util";
import { throttle } from "lodash";

const middlewares = [thunk, logger];
const persistedState = loadState();

const appStore = createStore(
  rootReducer,
  persistedState,
  applyMiddleware(...middlewares)
);

appStore.subscribe(
  throttle(() => {
    saveState({
      user: appStore.getState().user,
      cart: appStore.getState().cart,
      currency: appStore.getState().currency,
      loading: appStore.getState().loading
    });
  }, 1000)
);

export default appStore;
