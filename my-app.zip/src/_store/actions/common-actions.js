export const SET_LOADING = "SET_LOADING";

export const setLoading = status => {
  return { type: SET_LOADING, status };
};
