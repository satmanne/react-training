import { setLoading } from "./common-actions";
import axios from "axios";
export const STORE_USER = "STORE_USER";
export const SIGN_OUT = "SIGN_OUT";
export const SIGNIN_ERROR = "SIGNIN_ERROR";

export const createSession = user => {
  return { type: STORE_USER, user };
};

export const signOut = () => {
  return { type: SIGN_OUT };
};

export const signInError = error => {
  return { type: SIGNIN_ERROR, error };
};
// logical action
export const signIn = (email, password) => {
  return dispatch => {
    dispatch(setLoading(true)); // show loader
    const api =
      "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyAtmiEc1CaYH9NziL7NwGgLT_jp92VdvjU";
    const data = { email, password, returnSecureToken: true };
    // ajax request
    axios
      .post(api, data)
      .then(res => {
        dispatch(setLoading(false)); // close the loader
        dispatch(createSession(res.data)); // create session
      })
      .catch(err => {
        dispatch(setLoading(false));
        dispatch(signInError(err.response.data));
      });
  };
};
