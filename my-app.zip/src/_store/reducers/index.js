import { combineReducers } from "redux";
import currencyReducer from "./currency-reducer";
import cartReducer from "./cart-reducer";
import commonReducer from "./common-reducer";
import userReducer from "./user-reducer";

const rootReducer = combineReducers({
  currency: currencyReducer,
  cart: cartReducer,
  loading: commonReducer,
  user: userReducer
});

export default rootReducer;
