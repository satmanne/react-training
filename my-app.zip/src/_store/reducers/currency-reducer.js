import { CHANGE_CURRENCY } from "../actions/currency-actions";

// function reducer(state,action)
function currencyReducer(state = "USD", action) {
  switch (action.type) {
    case CHANGE_CURRENCY:
      return action.code;
    default:
      return state;
  }
}
export default currencyReducer;
