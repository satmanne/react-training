import { STORE_USER, SIGN_OUT, SIGNIN_ERROR } from "../actions";

const userState = {
  user: null,
  error: null
};
function userReducer(state = userState, action) {
  switch (action.type) {
    case STORE_USER:
      return { ...userState, user: action.user };
    case SIGNIN_ERROR:
      return { ...userState, error: action.error };
    case SIGN_OUT:
      return userState;
    default:
      return state;
  }
}
export default userReducer;
