import React from "react";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import Demo from "./Demo";
//import ProductList from "./containers/ProductList";
import Cart from "./containers/Cart";
import ErrorPage from "./components/ErrorPage";
import Checkout from "./containers/Checkout";
import Login from "./containers/Login";
import PrivateRoute from "./components/PrivateRoute";
import Loader from "./components/Loader";
import InfiniteList from "./containers/InfiniteList";
const LazyProductList = React.lazy(() => import("./containers/ProductList"));

function AppRouter(props) {
  return (
    <div style={{ marginTop: "4rem" }}>
      <React.Suspense fallback={<Loader />}>
        <Switch>
          <Route path="/" component={Demo} exact />
          <Route path="/products" component={LazyProductList} />
          <Route path="/infinitescroll" component={InfiniteList} />
          <Route path="/cart" component={Cart} />
          <Route path="/login" component={Login} />
          <PrivateRoute path="/checkout/:id" component={Checkout} />
          <Route component={ErrorPage} />
        </Switch>
      </React.Suspense>
    </div>
  );
}
export default AppRouter;
