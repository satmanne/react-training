import React from "react";

function Container(props) {
  const cls = props.full ? "container-fluid" : "container";
  return <div className={cls}>{props.children}</div>;
}
export default Container;
