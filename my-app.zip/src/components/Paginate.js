import React from "react";

function Paginate(props) {
  const { length, size, pageChange } = props;
  const pageCount = Math.ceil(length / size);
  const pages = Array(pageCount).fill(0);
  return (
    <div className="text-center">
      <div className="btn-group" role="group">
        {pages.map((val, index) => (
          <button
            type="button"
            className="btn btn-sm btn-info"
            key={index}
            onClick={() => pageChange(index + 1)}
          >
            {index + 1}
          </button>
        ))}
      </div>
    </div>
  );
}
export default Paginate;
