import React from "react";
import { connect } from "react-redux";
import { changeCurrency } from "../_store/actions";

class Currency extends React.Component {
  render() {
    const currencies = ["INR", "USD", "EUR", "CAD", "GBP"];
    return (
      <select
        value={this.props.currentCurrency}
        className="form-control-sm ml-2"
        onChange={e => this.props.updateCurrency(e.currentTarget.value)}
      >
        {currencies.map(code => (
          <option key={code}>{code}</option>
        ))}
      </select>
    );
  }
}
// connect(what to retrieve, what to modify)(component)
const mapDispatchToProps = dispatch => {
  return {
    updateCurrency: code => dispatch(changeCurrency(code))
  };
};
const mapStateToProps = state => {
  return {
    currentCurrency: state.currency
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Currency);
