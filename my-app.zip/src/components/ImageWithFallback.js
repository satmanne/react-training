import React from "react";
import Loader from "./Loader";

// 1.jpg
// default.jpg
function ImageWithFallback(props) {
  // let [state,setState]=React.useState(default value)
  let [imgSrc, updateImage] = React.useState(props.source);
  let [visible, setVisible] = React.useState(false);
  const visibility = visible ? "visible" : "invisible";
  const defaultImage =
    "https://previews.123rf.com/images/pavelstasevich/pavelstasevich1811/pavelstasevich181101028/112815904-no-image-available-icon-flat-vector-illustration.jpg";
  return (
    <>
      {visible ? null : <Loader color="dark" />}
      <img
        src={imgSrc}
        className={"img-thumbnail " + visibility}
        onLoad={() => setVisible(true)}
        onError={() => updateImage(defaultImage)}
      />
    </>
  );
  //   return (
  //     <img
  //       src={props.source}
  //       onError={e => (e.currentTarget.src = "/default.jpg")}
  //     />
  //   );
}
export default ImageWithFallback;
