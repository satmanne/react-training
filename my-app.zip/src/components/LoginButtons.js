import React from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { signOut } from "../_store/actions";

function LoginButtons(props) {
  const theme = props.theme ? "light" : "dark";
  const cls = `btn btn-outline-${theme} btn-sm mx-2`;
  if (props.isLoggedIn) {
    return (
      <button className={cls} onClick={() => props.logout()}>
        Logout
      </button>
    );
  }
  return (
    <Link className={cls} to={"/login"}>
      Login
    </Link>
  );
}
const mapStateToProps = state => {
  return { isLoggedIn: !!state.user.user };
};
const mapDispatchToProps = dispatch => {
  return { logout: () => dispatch(signOut()) };
};
export default connect(mapStateToProps, mapDispatchToProps)(LoginButtons);
