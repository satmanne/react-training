// Textbox.js
import React from "react";

function Textbox(props) {
  // useState
  let [errorMsg, updateStatus] = React.useState(false);
  const { value, valueChange, name, type } = props;
  return (
    <div className="form-group">
      <label>{name}</label>

      <input
        type={type}
        className="form-control"
        value={value}
        placeholder={name}
        onChange={e => valueChange(e.currentTarget.value)}
        onBlur={() => updateStatus(true)}
        onFocus={() => updateStatus(false)}
      />

      {errorMsg && value === "" ? (
        <small className="text-danger">{name} is required</small>
      ) : null}
    </div>
  );
}
export default Textbox;
