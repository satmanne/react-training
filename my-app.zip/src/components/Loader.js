import React from "react";

function Loader(props) {
  const color = props.color ? "text-" + props.color : "";
  return (
    <div className={"spinner-grow " + color} role="status">
      <span className="sr-only">Loading...</span>
    </div>
  );
}
export default Loader;
