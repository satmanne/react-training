import React from "react";
import { connect } from "react-redux";

function ButtonWithLoader(props) {
  const { color, text, click, type, small, block, loading } = props;
  const colorCls = "btn btn-" + color;
  const sizeCls = small ? "btn-sm" : "";
  const blockCls = block ? "btn-block" : "";
  if (!loading) {
    return (
      <button
        onClick={() => {
          if (type === "button") {
            click();
          }
        }}
        type={type}
        className={`${colorCls} ${sizeCls} ${blockCls}`}
      >
        {text}
      </button>
    );
  }
  return (
    <button className={`${colorCls} ${sizeCls} ${blockCls}`}>
      <div class="spinner-border text-light" role="status">
        <span class="sr-only">Loading...</span>
      </div>
    </button>
  );
}
const mapStateToProps = state => {
  return { loading: state.loading };
};
export default connect(mapStateToProps)(ButtonWithLoader);
