import React from "react";
import Column from "./Column";
import { Link } from "react-router-dom";

function ErrorPage(props) {
  return (
    <Column size={1}>
      <div id="notfound">
        <div className="notfound">
          <div className="notfound-404">
            <h3>Oops! Page not found</h3>
            <h1>
              <span>4</span>
              <span>0</span>
              <span>4</span>
            </h1>
          </div>
          <h2>we are sorry, but the page you requested was not found</h2>
          <Link className="btn btn-warning text-white" to="/">
            GO TO HOME
          </Link>
        </div>
      </div>
    </Column>
  );
}
export default ErrorPage;
