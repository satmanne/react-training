import React from "react";

function ThemeSwitch(props) {
  let [color, setColor] = React.useState("");
  return (
    <div className="custom-control custom-switch">
      <input
        type="checkbox"
        className="custom-control-input"
        onChange={e => {
          const checked = e.currentTarget.checked;
          props.changeTheme(checked);
          const c = checked ? "text-white" : "";
          setColor(c);
        }}
        id="customSwitch"
      />
      <label className={"custom-control-label " + color} htmlFor="customSwitch">
        Dark Mode
      </label>
    </div>
  );
}
export default ThemeSwitch;
