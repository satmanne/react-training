import React from "react";
import { NavLink } from "react-router-dom";

function Menu(props) {
  return (
    <ul className="navbar-nav mr-auto">
      {props.menuItems.map((menu, index) => (
        <li className="nav-item" key={index}>
          <NavLink
            exact
            className="nav-link"
            to={menu.menuLink}
            activeClassName={"active"}
          >
            {menu.menuText}
          </NavLink>
        </li>
      ))}
    </ul>
  );
}
export default Menu;
