import React from "react";
import ImageWithFallback from "./ImageWithFallback";
import Column from "./Column";

class Product extends React.Component {
  renderStock(stock, wishlist) {
    if (stock) {
      return (
        <button
          className="btn btn-block btn-sm btn-primary"
          onClick={() => this.props.btnClick()}
        >
          <i className="fas fa-cart-plus"></i> Add To{" "}
          {wishlist ? "Wishlist" : "Cart"}
        </button>
      );
    }
    return (
      <button disabled className="btn btn-block btn-sm btn-danger">
        <strike>Out of Stock</strike>
      </button>
    );
  }
  render() {
    const { pData, wishlist, code } = this.props;
    return (
      <Column size={4}>
        <div className="p-4 text-center shadow my-2">
          <ImageWithFallback source={pData.productImage} />
          <h3>{pData.productName}</h3>
          <h4>
            {code} {Number(pData.productPrice).toFixed(2)}
          </h4>
          {/* <button>Add To {wishlist ? "Wishlist" : "Cart"}</button> */}
          {this.renderStock(pData.productStock, wishlist)}
        </div>
      </Column>
    );
  }
}
export default Product;
