import React from "react";
import { ThemeContext } from "../App";

function Column(props) {
  const darkMode = React.useContext(ThemeContext);
  const colSize = 12 / props.size;
  const cls = "col-md-" + colSize;
  const color = darkMode ? " text-white" : "";

  return <div className={cls + color}>{props.children}</div>;
}
export default Column;
