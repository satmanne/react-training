import React from "react";
class Demo extends React.Component {
  state = { no: 0, a: 1 };

  shouldComponentUpdate(nextProps, nextState) {
    console.log(nextProps, nextState);
    return this.state.no !== nextState.no;
  }

  render() {
    console.log("render called", this.state);

    const name = "Demo";
    return (
      <div>
        <button onClick={() => this.setState({ a: 2 })}>change to 2</button>

        <button onClick={() => this.setState({ no: 1 })}>change to 1</button>
        <button onClick={() => this.setState({ no: 0 })}>change to 0</button>
        <p>TEST Component</p>
        <p>Some more content</p>
        <p>Hello from {name}</p>
        <p>{8 + 7}</p>
      </div>
    );
  }
}
export default Demo;
